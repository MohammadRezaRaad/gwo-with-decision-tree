/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package uni_conf;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEntity;
import org.cloudbus.cloudsim.core.SimEvent;
import org.cloudbus.cloudsim.lists.CloudletList;
import org.cloudbus.cloudsim.lists.VmList;


/**
 * DatacentreBroker represents a broker acting on behalf of a user. 
 * It hides VM management, as vm creation, sumbission of cloudlets to this VMs and destruction of VMs.
 * 
 * @author Rodrigo N. Calheiros
 * @author Anton Beloglazov
 * @since CloudSim Toolkit 1.0
 */
public class DatacenterBroker_uni_conf extends SimEntity {

	public static List<? extends Vm> vmList;											// the vm list
	protected List<? extends Vm> vmsCreatedList;										// the vms created list
	public static List<? extends Cloudlet> cloudletList;								// the cloudlet list
	protected List<? extends Cloudlet> cloudletSubmittedList;							// the cloudlet submitted list
	protected List<? extends Cloudlet> cloudletReceivedList;							// the cloudlet received list
	protected int cloudletsSubmitted;													// the cloudlets submitted
	protected int vmsRequested;															// the vms requested
	protected int vmsAcks;																// the vms acks
	protected int vmsDestroyed;															// the vms destroyed
	protected List<Integer> datacenterIdsList;											// the datacenter ids list
	protected List<Integer> datacenterRequestedIdsList;									// the datacenter requested ids list
	protected Map<Integer, Integer> vmsToDatacentersMap;								// the vms to datacenters map
	protected Map<Integer, DatacenterCharacteristics> datacenterCharacteristicsList;	// the datacenter characteristics list

	public static int myAi = 0;	
	public static int broker_taskIndex = 0;
	public static int broker_vmIndex = 0;
	public static List<Vm> list_opt;	
	
	/** intAI() */
	public void intAI(int a) {
		myAi = a;
	}
	
	public static double findTime_all = 0;
	public static double findTime_all_clock = 0;
	
	public static double[][] ft_list;
	private static double submit_time;
	
	private static double[][] runStartT;
	
	private static double x1 = 0;
	private static double x2 = 0;
	

		
	///////////////////////////////////////
	
	
	/**
	 * Created a new DatacenterBroker object.
	 * 
	 * @param name name to be associated with this entity (as required by Sim_entity class from simjava package)
	 * @throws Exception the exception
	 * @pre name != null
	 * @post $none
	 */
	public DatacenterBroker_uni_conf(String name) throws Exception {
		super(name);

		setVmList(new ArrayList<Vm>());
		setVmsCreatedList(new ArrayList<Vm>());
		setCloudletList(new ArrayList<Cloudlet>());
		setCloudletSubmittedList(new ArrayList<Cloudlet>());
		setCloudletReceivedList(new ArrayList<Cloudlet>());

		cloudletsSubmitted = 0;
		setVmsRequested(0);
		setVmsAcks(0);
		setVmsDestroyed(0);

		setDatacenterIdsList(new LinkedList<Integer>());
		setDatacenterRequestedIdsList(new ArrayList<Integer>());
		setVmsToDatacentersMap(new HashMap<Integer, Integer>());
		setDatacenterCharacteristicsList(new HashMap<Integer, DatacenterCharacteristics>());
	}

	
	
	/**
	 * This method is used to send to the broker the list with virtual machines that must be created.
	 * 
	 * @param list
	 * @param vms_i
	 */
	public void submitVmList(List<? extends Vm> list, int vms_i) {
		getVmList().addAll(list);
	}

	
	
	/**
	 * This method is used to send to the broker the list of cloudlets.
	 * 
	 * @param list
	 * @param tasks_i
	 */
	public void submitCloudletList(List<? extends Cloudlet> list, int tasks_i) {
		getCloudletList().addAll(list);
	}

	
	
	/**
	 * Specifies that a given cloudlet must run in a specific virtual machine.
	 * 
	 * @param cloudletId
	 * @param vmId
	 */
	public void bindCloudletToVm(int cloudletId, int vmId) {
		CloudletList.getById(getCloudletList(), cloudletId).setVmId(vmId);
	}

	
	
	/**
	 * Processes events available for this Broker.
	 * 
	 * @param ev a SimEvent object
	 * @pre ev != null
	 * @post $none
	 */
	@Override
	public void processEvent(SimEvent ev) {
		switch (ev.getTag()) {
		// Resource characteristics request
			case CloudSimTags.RESOURCE_CHARACTERISTICS_REQUEST:
				processResourceCharacteristicsRequest(ev);
				break;
			// Resource characteristics answer
			case CloudSimTags.RESOURCE_CHARACTERISTICS:
				processResourceCharacteristics(ev);
				break;
			// VM Creation answer
			case CloudSimTags.VM_CREATE_ACK:
				processVmCreate(ev);
				break;
			// A finished cloudlet returned
			case CloudSimTags.CLOUDLET_RETURN:
				processCloudletReturn(ev);
				break;
			// if the simulation finishes
			case CloudSimTags.END_OF_SIMULATION:
				shutdownEntity();
				break;
			// other unknown tags are processed by this method
			default:
				processOtherEvent(ev);
				break;
		}
	}

	
	
	/**
	 * Process a request for the characteristics of a PowerDatacenter.
	 * 
	 * @param ev a SimEvent object
	 * @pre ev != $null
	 * @post $none
	 */
	protected void processResourceCharacteristicsRequest(SimEvent ev) {
		setDatacenterIdsList(CloudSim.getCloudResourceList());
		setDatacenterCharacteristicsList(new HashMap<Integer, DatacenterCharacteristics>());

		Log.printLine(CloudSim.clock() + ": " + getName() + ": Cloud Resource List received with "
				+ getDatacenterIdsList().size() + " resource(s)");

		for (Integer datacenterId : getDatacenterIdsList()) {
			sendNow(datacenterId, CloudSimTags.RESOURCE_CHARACTERISTICS, getId());
		}
	}

	
	
	/**
	 * Process the return of a request for the characteristics of a PowerDatacenter.
	 * 
	 * @param ev a SimEvent object
	 * @pre ev != $null
	 * @post $none
	 */
	protected void processResourceCharacteristics(SimEvent ev) {
		DatacenterCharacteristics characteristics = (DatacenterCharacteristics) ev.getData();
		getDatacenterCharacteristicsList().put(characteristics.getId(), characteristics);

		if (getDatacenterCharacteristicsList().size() == getDatacenterIdsList().size()) {
			setDatacenterRequestedIdsList(new ArrayList<Integer>());
			createVmsInDatacenter(getDatacenterIdsList().get(0));
		}
	}
	
	

	/**
	 * Process the ack received due to a request for VM creation.
	 * 
	 * @param ev a SimEvent object
	 * @pre ev != null
	 * @post $none
	 */
	protected void processVmCreate(SimEvent ev) {
		
		int[] data = (int[]) ev.getData();
		int datacenterId = data[0];
		int vmId = data[1];
		int result = data[2];
		
		
		if (result == CloudSimTags.TRUE) {
			
			getVmsToDatacentersMap().put(vmId, datacenterId);
			getVmsCreatedList().add(VmList.getById(getVmList(), vmId));
			
			Log.printLine(CloudSim.clock() + ": " + getName() + ": VM #" + vmId
					+ " has been created in Datacenter #" + datacenterId + ", Host #"
					+ VmList.getById(getVmsCreatedList(), vmId).getHost().getId());
			
		} else {
			Log.printLine(CloudSim.clock() + ": " + getName() + ": Creation of VM #" + vmId
					+ " failed in Datacenter #" + datacenterId);
		}

		// vmsAcks++
		incrementVmsAcks();

		// all the requested VMs have been created
		if (getVmsCreatedList().size() == getVmList().size() - getVmsDestroyed()) {
			
			submitCloudlets();
			
		} else {
			// all the acks received, but some VMs were not created
			if (getVmsRequested() == getVmsAcks()) {
				// find id of the next datacenter that has not been tried
				for (int nextDatacenterId : getDatacenterIdsList()) {
					if (!getDatacenterRequestedIdsList().contains(nextDatacenterId)) {
						createVmsInDatacenter(nextDatacenterId);
						return;
					}
				}

				// all datacenters already queried
				if (getVmsCreatedList().size() > 0) { // if some vm were created
					
					submitCloudlets();
					
				} else { // no vms created. abort
					Log.printLine(CloudSim.clock() + ": " + getName()
							+ ": none of the required VMs could be created. Aborting");
					finishExecution();
				}
			}
		}
	}


	
	/**
	 * Process a cloudlet return event.
	 * 
	 * @param ev a SimEvent object
	 * @pre ev != $null
	 * @post $none
	 */
	protected void processCloudletReturn(SimEvent ev) {
		
		Cloudlet cloudlet = (Cloudlet) ev.getData();
		getCloudletReceivedList().add(cloudlet);
		
		Log.printLine(CloudSim.clock() + ": " + getName() + ": Cloudlet " + cloudlet.getCloudletId() + " received");
		
		
		// decrease
		int vmLoad_first = getVmList().get(cloudlet.getVmId()).getVmLoad();
		int taskLoad_second = (int) cloudlet.getCloudletLength();
		int load_decrease = vmLoad_first - taskLoad_second;
		getVmList().get(cloudlet.getVmId()).setVmLoad(load_decrease);
		

		cloudletsSubmitted--;

		
		if (getCloudletList().size() == 0 && cloudletsSubmitted == 0) { // all cloudlets executed
			
			
			//TODO - makespan => System.currentTimeMillis()
			System.out.println("\n");
			x2 = System.currentTimeMillis();
			System.out.println("x2 = " + x2);
			System.out.println("\n");
			
			
			Log.printLine(CloudSim.clock() + ": " + getName() + ": All Cloudlets executed. Finishing...");
			Log.printLine(System.currentTimeMillis() + ": " + getName() + ": All Cloudlets executed. Finishing...");

			clearDatacenters();		// clear
			finishExecution();		// finish
			
		} else { // some cloudlets haven't finished yet
			if (getCloudletList().size() > 0 && cloudletsSubmitted == 0) {
				// all the cloudlets sent finished.
				// It means that some bount cloudlet is waiting its VM be created
				clearDatacenters();
				createVmsInDatacenter(0);
			}
		}
	}


	
	/**
	 * Overrides this method when making a new and different type of Broker. 
	 * This method is called by {@link #body()} for incoming unknown tags.
	 * 
	 * @param ev a SimEvent object
	 * @pre ev != null
	 * @post $none
	 */
	protected void processOtherEvent(SimEvent ev) {
		if (ev == null) {
			Log.printLine(getName() + ".processOtherEvent(): " + "Error - an event is null.");
			return;
		}
		
		Log.printLine(getName() + ".processOtherEvent(): " + "Error - event unknown by this DatacenterBroker.");
	}

	
	
	/**
	 * Create the virtual machines in a datacenter.
	 * 
	 * @param datacenterId Id of the chosen PowerDatacenter
	 * @pre $none
	 * @post $none
	 */
	protected void createVmsInDatacenter(int datacenterId) {
		// send as much vms as possible for this datacenter before trying the next one
		int requestedVms = 0;
		String datacenterName = CloudSim.getEntityName(datacenterId);
		
		for (Vm vm : getVmList()) {
			
			if (!getVmsToDatacentersMap().containsKey(vm.getId())) {
				
				Log.printLine(CloudSim.clock() + ": " + getName() + ": Trying to Create VM #" + vm.getId() + " in " + datacenterName);
			
				sendNow(datacenterId, CloudSimTags.VM_CREATE_ACK, vm);
				requestedVms++;
			}
		}

		getDatacenterRequestedIdsList().add(datacenterId);
		setVmsRequested(requestedVms);
		setVmsAcks(0);
	}

	
	
	/**
	 * Destroy the virtual machines running in datacenters.
	 * 
	 * @pre $none
	 * @post $none
	 */
	protected void clearDatacenters() {
		
		for (Vm vm : getVmsCreatedList()) {
			Log.printLine(CloudSim.clock() + ": " + getName() + ": Destroying VM #" + vm.getId());
			
			sendNow(getVmsToDatacentersMap().get(vm.getId()), CloudSimTags.VM_DESTROY, vm);
		}

		getVmsCreatedList().clear();
	}
	
	

	/**
	 * Send an internal event communicating the end of the simulation.
	 * 
	 * @pre $none
	 * @post $none
	 */
	protected void finishExecution() {
		sendNow(getId(), CloudSimTags.END_OF_SIMULATION);
	}

	
	
	/*
	 * (non-Javadoc)
	 * @see cloudsim.core.SimEntity#shutdownEntity()
	 */
	@Override
	public void shutdownEntity() {
		Log.printLine(getName() + " is shutting down...");
	}
	
	

	/*
	 * (non-Javadoc)
	 * @see cloudsim.core.SimEntity#startEntity()
	 */
	@Override
	public void startEntity() {
		Log.printLine(getName() + " is starting...");
		schedule(getId(), 0, CloudSimTags.RESOURCE_CHARACTERISTICS_REQUEST);
	}

	
	
	/**
	 * Gets the vm list.
	 * 
	 * @param <T> the generic type
	 * @return the vm list
	 */
	@SuppressWarnings("unchecked")
	public static <T extends Vm> List<T> getVmList() {
		return (List<T>) vmList;
	}

	
	
	/**
	 * Sets the vm list.
	 * 
	 * @param <T> the generic type
	 * @param vmList the new vm list
	 */
	protected <T extends Vm> void setVmList(List<T> vmList) {
		DatacenterBroker_uni_conf.vmList = vmList;
	}
	
	

	/**
	 * Gets the cloudlet list.
	 * 
	 * @param <T> the generic type
	 * @return the cloudlet list
	 */
	@SuppressWarnings("unchecked")
	public static <T extends Cloudlet> List<T> getCloudletList() {
		return (List<T>) cloudletList;
	}
	
	

	/**
	 * Sets the cloudlet list.
	 * 
	 * @param <T> the generic type
	 * @param cloudletList the new cloudlet list
	 */
	protected <T extends Cloudlet> void setCloudletList(List<T> cloudletList) {
		DatacenterBroker_uni_conf.cloudletList = cloudletList;
	}

	
	
	/**
	 * Gets the cloudlet submitted list.
	 * 
	 * @param <T> the generic type
	 * @return the cloudlet submitted list
	 */
	@SuppressWarnings("unchecked")
	public <T extends Cloudlet> List<T> getCloudletSubmittedList() {
		return (List<T>) cloudletSubmittedList;
	}

	
	
	/**
	 * Sets the cloudlet submitted list.
	 * 
	 * @param <T> the generic type
	 * @param cloudletSubmittedList the new cloudlet submitted list
	 */
	protected <T extends Cloudlet> void setCloudletSubmittedList(List<T> cloudletSubmittedList) {
		this.cloudletSubmittedList = cloudletSubmittedList;
	}

	
	
	/**
	 * Gets the cloudlet received list.
	 * 
	 * @param <T> the generic type
	 * @return the cloudlet received list
	 */
	@SuppressWarnings("unchecked")
	public <T extends Cloudlet> List<T> getCloudletReceivedList() {
		return (List<T>) cloudletReceivedList;
	}
	
	

	/**
	 * Sets the cloudlet received list.
	 * 
	 * @param <T> the generic type
	 * @param cloudletReceivedList the new cloudlet received list
	 */
	protected <T extends Cloudlet> void setCloudletReceivedList(List<T> cloudletReceivedList) {
		this.cloudletReceivedList = cloudletReceivedList;
	}

	
	
	/**
	 * Gets the vm list.
	 * 
	 * @param <T> the generic type
	 * @return the vm list
	 */
	@SuppressWarnings("unchecked")
	public <T extends Vm> List<T> getVmsCreatedList() {
		return (List<T>) vmsCreatedList;
	}

	
	
	/**
	 * Sets the vm list.
	 * 
	 * @param <T> the generic type
	 * @param vmsCreatedList the vms created list
	 */
	protected <T extends Vm> void setVmsCreatedList(List<T> vmsCreatedList) {
		this.vmsCreatedList = vmsCreatedList;
	}

	
	
	/**
	 * Gets the vms requested.
	 * 
	 * @return the vms requested
	 */
	protected int getVmsRequested() {
		return vmsRequested;
	}

	
	
	/**
	 * Sets the vms requested.
	 * 
	 * @param vmsRequested the new vms requested
	 */
	protected void setVmsRequested(int vmsRequested) {
		this.vmsRequested = vmsRequested;
	}

	
	
	/**
	 * Gets the vms acks.
	 * 
	 * @return the vms acks
	 */
	protected int getVmsAcks() {
		return vmsAcks;
	}

	
	
	/**
	 * Sets the vms acks.
	 * 
	 * @param vmsAcks the new vms acks
	 */
	protected void setVmsAcks(int vmsAcks) {
		this.vmsAcks = vmsAcks;
	}
	
	

	/**
	 * Increment vms acks.
	 */
	protected void incrementVmsAcks() {
		vmsAcks++;
	}

	
	
	/**
	 * Gets the vms destroyed.
	 * 
	 * @return the vms destroyed
	 */
	protected int getVmsDestroyed() {
		return vmsDestroyed;
	}

	
	
	/**
	 * Sets the vms destroyed.
	 * 
	 * @param vmsDestroyed the new vms destroyed
	 */
	protected void setVmsDestroyed(int vmsDestroyed) {
		this.vmsDestroyed = vmsDestroyed;
	}

	
	
	/**
	 * Gets the datacenter ids list.
	 * 
	 * @return the datacenter ids list
	 */
	protected List<Integer> getDatacenterIdsList() {
		return datacenterIdsList;
	}

	
	
	/**
	 * Sets the datacenter ids list.
	 * 
	 * @param datacenterIdsList the new datacenter ids list
	 */
	protected void setDatacenterIdsList(List<Integer> datacenterIdsList) {
		this.datacenterIdsList = datacenterIdsList;
	}

	
	
	/**
	 * Gets the vms to datacenters map.
	 * 
	 * @return the vms to datacenters map
	 */
	protected Map<Integer, Integer> getVmsToDatacentersMap() {
		return vmsToDatacentersMap;
	}

	
	
	/**
	 * Sets the vms to datacenters map.
	 * 
	 * @param vmsToDatacentersMap the vms to datacenters map
	 */
	protected void setVmsToDatacentersMap(Map<Integer, Integer> vmsToDatacentersMap) {
		this.vmsToDatacentersMap = vmsToDatacentersMap;
	}

	
	
	/**
	 * Gets the datacenter characteristics list.
	 * 
	 * @return the datacenter characteristics list
	 */
	protected Map<Integer, DatacenterCharacteristics> getDatacenterCharacteristicsList() {
		return datacenterCharacteristicsList;
	}

	
	
	/**
	 * Sets the datacenter characteristics list.
	 * 
	 * @param datacenterCharacteristicsList the datacenter characteristics list
	 */
	protected void setDatacenterCharacteristicsList(Map<Integer, DatacenterCharacteristics> datacenterCharacteristicsList) {
		this.datacenterCharacteristicsList = datacenterCharacteristicsList;
	}

	
	
	/**
	 * Gets the datacenter requested ids list.
	 * 
	 * @return the datacenter requested ids list
	 */
	protected List<Integer> getDatacenterRequestedIdsList() {
		return datacenterRequestedIdsList;
	}

	
	
	/**
	 * Sets the datacenter requested ids list.
	 * 
	 * @param datacenterRequestedIdsList the new datacenter requested ids list
	 */
	protected void setDatacenterRequestedIdsList(List<Integer> datacenterRequestedIdsList) {
		this.datacenterRequestedIdsList = datacenterRequestedIdsList;
	}


	// *********************************************************************
	

	/** submitCloudlets() */
	protected void submitCloudlets() {
		
		// print vmLoad
		System.out.println("\nvmLoad = ");
		for (int i = 0; i < getVmList().size(); i++) 
			System.out.print(getVmList().get(i).getVmLoad() + " ");
		System.out.println("\n");
		
		// VM_ID
		int tempVmID = 0;
		int myVmID = 0;
				
		// before this we must not define the sizeVm & sizeClouslet
		int sizeVm = getVmList().size();
		int sizeCloudlet = getCloudletList().size();
		
		ft_list = new double[sizeCloudlet][sizeVm];
		runStartT = new double[sizeCloudlet][sizeVm];
		for (int i = 0; i < sizeCloudlet; i++) {
			for (int j = 0; j < sizeVm; j++) {
				ft_list[i][j] = 0;
				runStartT[i][j] = 0;
			}
		}
		
		
		int dim_i = sizeVm;
		int lb_i = 0;
		int ub_i = dim_i-1;
		
//		list_opt = getVmList();

		
		// add cloudlet to vm
		double findTime_start = 0;
		double findTime_finish = 0;
		double delta = 0;
		
		double findTime_startClock = 0;
		double findTime_finishClock = 0;
		double deltaClock = 0;
		
		
		double submit_time_start = System.currentTimeMillis();
		
		for (int i = 0; i < sizeCloudlet; i++) {

			broker_taskIndex = i;
			
			
			findTime_start = System.currentTimeMillis();
			findTime_startClock = CloudSim.clock();
			
			// classification
			if (myAi == 1) {
				list_opt = myDecisionTree();	// decision tree
			} else {
				list_opt = getVmList();			// normal (without classification)
			}

			findTime_finish = System.currentTimeMillis();
			findTime_finishClock = CloudSim.clock();
			
			
			delta = findTime_finish - findTime_start;
			deltaClock = findTime_finishClock - findTime_startClock;
			
			findTime_all += delta;
			findTime_all_clock += deltaClock;
			
			
//			delta += (findTime_finish - findTime_start);
			
			
			
			
//			//TODO
//			System.out.print("\nlist_opt = ");
//			for (int j = 0; j < list_opt.size(); j++) 
//				System.out.print(list_opt.get(j).getId() + " ");
//			System.out.println();
			
			
			
			// update variables
			sizeVm = list_opt.size();
			dim_i = sizeVm;
			lb_i = 0;
			ub_i = dim_i; //TODO
			
			
			// VM_ID
//			myVmID = 6;
//			myVmID = random_range(0, sizeVm);
			tempVmID = myGWO(list_opt, dim_i, lb_i, ub_i);
//			myVmID = list_opt.get(tempVmID).getId();
			broker_vmIndex = list_opt.get(tempVmID).getId();
			
			
			// increase
			int vmLoadFirst = getVmList().get(broker_vmIndex).getVmLoad();
			int taskLoadSecond = (int) getCloudletList().get(broker_taskIndex).getCloudletLength();
			int load_increase = vmLoadFirst + taskLoadSecond;
			getVmList().get(broker_vmIndex).setVmLoad(load_increase);
						
			
			//TODO - runStartTime
			runStartT[broker_taskIndex][broker_vmIndex] = System.currentTimeMillis();
			
			
			// set VmId
			getCloudletList().get(i).setVmId(broker_vmIndex);
			
			// print Log
			Log.printLine(CloudSim.clock() + ": " + getName() + ": Sending cloudlet " 
						+ getCloudletList().get(i).getCloudletId() + " to VM #" + broker_vmIndex);
			
			// sendNow
			sendNow(getVmsToDatacentersMap().get(broker_vmIndex), CloudSimTags.CLOUDLET_SUBMIT, getCloudletList().get(i));
			
			// cloudletsSubmitted
			cloudletsSubmitted++;
			getCloudletSubmittedList().add(getCloudletList().get(i));
			

		}
		double submit_time_finish = System.currentTimeMillis();

		
		ft_list[broker_taskIndex][broker_vmIndex] = findTime_finish - findTime_start;
		
		submit_time = submit_time_finish - submit_time_start;
		
		
		/*
		 *  remove submitted cloudlets from waiting list
		 */
		for (int i = 0; i < getCloudletSubmittedList().size(); i++) {
			getCloudletList().remove(getCloudletSubmittedList().get(i));
		}
		
	}
	
	

	/** random_range() */
	public static int random_range(int min, int max) {
		return (int) (Math.random() * (max - min) + min);
	}

	
	
	/** myGWO() */
	public static int myGWO(List<Vm> list_opt, int dim, int lb, int ub) {
		int vm_id = 0;
		
		int maxIter = 100;
		int N = 10;
		
		double r1 = 0;
		double r2 = 0;
		double[] a = new double[dim];
		double[] A1 = new double[dim];
		double[] C1 = new double[dim];
		double[] A2 = new double[dim];
		double[] C2 = new double[dim];
		double[] A3 = new double[dim];
		double[] C3 = new double[dim];
		
		double[] alfa = new double[dim];
		double[] beta = new double[dim];
		double[] delta = new double[dim];
		
		int[] alfa_final = new int[dim];
		int[] beta_final = new int[dim];
		int[] delta_final = new int[dim];
		
		double[][] posVector = new double[N][dim];
		int[][] posVectorInt = new int[N][dim];
		
		double[][] X1 = new double[N][dim];
		double[][] X2 = new double[N][dim];
		double[][] X3 = new double[N][dim];
				
		int[] bestValue = new int[maxIter];
		
		
		// initialize the positions of search agents
		int result_index = 0;
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < dim; j++) {
				result_index = random_range(lb, ub);
				posVector[i][j] = list_opt.get(result_index).getId();
			}
		}

		
		// calculate the fitness of each search agent (row) & sort
		posVector = fitness_sort(posVector, N, dim);
				
		
		// set alfa, beta, delta -> based on sorted posVector
		for (int i = 0; i < dim; i++) {
			alfa[i] = posVector[0][i];
			beta[i] = posVector[1][i];
			delta[i] = posVector[2][i];
		}

		
		// ========== Iteration started ==========

		// main loop
		for (int iter = 0; iter < maxIter; iter++) {
			
			// a ==> decreases linearly from 2 to 0
			for (int z = 0; z < dim; z++) 
				a[z] = 2.0 - ((double) iter * (2.0 / (double) maxIter));
			
			
			// update the position of wolves based on alfa, beta, delta
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < dim; j++) {

                    // ---------------- Alfa ----------------
					r1 = Math.random();
					r2 = Math.random();
					for (int k = 0; k < dim; k++) {
						A1[k] = 2.0 * a[k] * r1 - a[k];												// Equation (3.3)
						C1[k] = 2.0 * r2;															// Equation (3.4)
					}
					X1[i][j] = alfa[j] - A1[j] * (Math.abs(C1[j] * alfa[j] - posVector[i][j]));		// Equation (3.5) & (3.6)
					X1 = simpleBounds(X1, N, dim, lb, ub);

					// ---------------- Beta ----------------
					r1 = Math.random();
					r2 = Math.random();
					for (int k = 0; k < dim; k++) {
						A2[k] = 2.0 * a[k] * r1 - a[k];												// Equation (3.3)
						C2[k] = 2.0 * r2;															// Equation (3.4)
					}				
					X2[i][j] = beta[j] - A2[j] * (Math.abs(C2[j] * beta[j] - posVector[i][j]));		// Equation (3.5) & (3.6)
					X2 = simpleBounds(X2, N, dim, lb, ub);

					// ---------------- Delta ----------------
					r1 = Math.random();
					r2 = Math.random();
					for (int k = 0; k < dim; k++) {
						A3[k] = 2.0 * a[k] * r1 - a[k];												// Equation (3.3)
						C3[k] = 2.0 * r2;															// Equation (3.4)
					}		
					X3[i][j] = delta[j] - A3[j] * (Math.abs(C3[j] * delta[j] - posVector[i][j]));	// Equation (3.5) & (3.6)
					X3 = simpleBounds(X3, N, dim, lb, ub);
			
					
					// calculate result => avrage
					posVector[i][j] = (X1[i][j] + X2[i][j] + X3[i][j]) / 3.0;						// Equation (3.7)
				}
			}
			
	
			// final ckeck
			posVectorInt = simpleBounds_new(posVector, N, dim, lb, ub);
			posVectorInt = fitness_sort_int(posVectorInt, N, dim);

			
			// new
			for (int i = 0; i < dim; i++) {
				posVectorInt[N-1][i] = posVectorInt[0][i];
			}
			for (int i = 0; i < dim; i++) {
				alfa_final[i] = posVectorInt[0][i];		// new alfa
				beta_final[i] = posVectorInt[1][i];		// new beta
				delta_final[i] = posVectorInt[2][i];	// new beta
			}		
			
			
			// store the best of iter
			bestValue[iter] = fitness_final(alfa_final);
		}
		
		// ========== Iteration finished ==========
		

		// fitness final => the best in bestValur[iter]
		vm_id = fitness_final(bestValue);

		
		return vm_id;
	}
	


	/** simpleBounds() */
	public static double[][] simpleBounds(double[][] posVector, int N, int dim, int lb, int ub) {
				
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < dim; j++) {
				
				if (posVector[i][j] < lb) 
					posVector[i][j] = (int) (Math.random() * (ub - lb)) * lb;
				
				if (posVector[i][j] > ub) 
					posVector[i][j] = (int) (Math.random() * (ub - lb)) * lb;		
			}
		}
		
		return posVector;
	}
	

	
	/** simpleBounds_new() */
	public static int[][] simpleBounds_new(double[][] posVector, int N, int dim, int lb, int ub) {
		int[][] posVectorInt = new int[N][dim];
		
		// double to int
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < dim; j++) {
				posVectorInt [i][j] = (int) posVector[i][j];
			}
		}
		
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < dim; j++) {
				
				if (posVectorInt[i][j] < lb) 
					posVectorInt[i][j] = (int) ((Math.random() * (ub - lb)) * lb);
				
				if (posVectorInt[i][j] > ub) 
					posVectorInt[i][j] = (int) ((Math.random() * (ub - lb)) * lb);		
			}
		}
		
		return posVectorInt;
	}
	
	
	
	/** fitness_sort() */
	public static double[][] fitness_sort(double[][] posVector, int N, int dim) {
		double[][] temp_posVector = new double[N][dim];
				
		int temp_flag_index = 0;
		double temp_flag = 0;
		int indexGet = 0;
		double remain = 0;
		
		int[] flag = new int[N];			
		double[] flag_treshold = new double[N];
		int[] tempSearch = new int[N];
		int[] flag_indexes = new int[N];

		
		// store int
		int[][] indexPosVec = new int[N][dim];
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < dim; j++) {
				indexPosVec[i][j] = (int) posVector[i][j];
			}
		}
		
		
		// flag (the best vm in each row)
		for (int i = 0; i < N; i++) {
			
			temp_flag_index = indexPosVec[i][0];
			temp_flag = normalization_cost(temp_flag_index);			
			
			for (int j = 0; j < dim; j++) {
				
				indexGet = indexPosVec[i][j];
				remain = normalization_cost(indexGet);
				
				if (remain < temp_flag) {
					temp_flag_index = indexGet;
					temp_flag = remain;
				}
			}
			flag[i] = temp_flag_index;			
		}
		
		
		// final task between results
		for (int i = 0; i < N; i++) {
			tempSearch[i] = flag[i];
			flag_treshold[i] = normalization_cost(flag[i]);
		}
		
		flag_indexes = sort_index_normal(flag_treshold);
		
		
		// temp_posVector must be compele based on [flag_indexes]
		for (int n = 0; n < flag_indexes.length; n++) {	// flag_indexes.length == N
			for (int d = 0; d < dim; d++) {
				temp_posVector[n][d] = indexPosVec[flag_indexes[n]][d];
			}
		}
		
		return temp_posVector;
	}
	
		
	
	/** fitness_sort_int() */
	public static int[][] fitness_sort_int(int[][] posVectorInt, int N, int dim) {
		int[][] temp_posVector = new int[N][dim];
		
		int temp_flag_index = 0;
		double temp_flag = 0;
		int indexGet = 0;
		double remain = 0;

		int[] flag = new int[N];
		double[] flag_treshold = new double[N];
		int[] tempSearch = new int[N];
		int[] flag_indexes = new int[N];

		
		// flag (the best vm in each row)
		for (int i = 0; i < N; i++) {

			temp_flag_index = posVectorInt[i][0];
			temp_flag = normalization_cost(temp_flag_index);
						
			for (int j = 0; j < dim; j++) {
				
				indexGet = posVectorInt[i][j];
				remain = normalization_cost(indexGet);
				
				if (remain < temp_flag) {
					temp_flag_index = indexGet;
					temp_flag = remain;
				}
			}
			flag[i] = temp_flag_index;
		}

		
		// final task between results
		for (int i = 0; i < N; i++) {
			tempSearch[i] = flag[i];
			flag_treshold[i] = normalization_cost(flag[i]);
		}
		
		flag_indexes = sort_index_normal(flag_treshold);
		
		
		// temp_posVector must be compele based on [flag_indexes]
		for (int n = 0; n < flag_indexes.length; n++) {	// flag_indexes.length == N
			for (int d = 0; d < dim; d++) {
				temp_posVector[n][d] = posVectorInt[flag_indexes[n]][d];
			}
		}
		
		return temp_posVector;
	}
	
	
	
	/** fitness_final() */
	public static int fitness_final(int[] myList) {
		int opt = 0;
		
		/*
		 * input --> int myList = alfa_final[dim] || bestValue[iter] 
		 * 
		 * process --> find minimun in list based on treshold
		 * 
		 * output --> int opt
		 */
				
		int best_index = myList[0];
		double best = normalization_cost(best_index);
		int indexGet = 0;
		double remain = 0;
		
		for (int i = 0; i < myList.length; i++) {
			
			indexGet = myList[i];
			remain = normalization_cost(indexGet);
			
			if (remain < best) {
				best_index = indexGet;
				best = remain;
			}
		}
		opt = best_index;		
		
		return opt;
	}
	
	
	
	/** normalization_cost() */
	public static double normalization_cost(int index) {	
			
		// remainResource formula
		/**
		 * load --> less is good
		 */
//		double remainResource = delta_size / delta_load;
		double remainResource = getVmList().get(index).getVmLoad();
				
		// return remainResource
		return remainResource;
	}

	
	
	/** sort_index_normal() */
	public static int[] sort_index_normal(double[] vector) {
		
		int vectorSize = vector.length;
		int[] elements = new int[vectorSize];
		int[] elements_index = new int[vectorSize];
		
		for (int i = 0; i < vectorSize; i++) {
			elements[i] = (int) vector[i];
		}
		
		
		for (int i = 0; i < vectorSize-1; i++) {
			// search the best element in the remaining array
			int bestPos = i;
			int best = elements[bestPos];
			
			for (int j = i+1; j < vectorSize; j++) {
				if (elements[j] < best) {
					bestPos = j;
					best = elements[bestPos];
				}
			}
			
			// swap best with element at pos i
			if (bestPos != i) {
				elements[bestPos] = elements[i];
				elements[i] = best;
			}
		}
		
		
		// search for index
		for (int k = 0; k < vectorSize; k++) {
			for (int i = 0; i < vectorSize; i++) {
				if (elements[k] == vector[i]) {
					elements_index[k] = i;
				}
			}
		}
		
		return elements_index;		
	}
	
	
	
	/** myDecisionTree() */
	public List<Vm> myDecisionTree() {
		
		// find min & max
		double load_temp = 0;
		double load_min = normalization_cost(0);
		double load_max = normalization_cost(0);
		int loadMinId = 0;
	
		for (int i = 0; i < getVmList().size(); i++) {
			load_temp = normalization_cost(i);
			
			if (load_temp < load_min) {
				load_min = load_temp;
				loadMinId = i;
			}
			
			if (load_temp > load_max) {
				load_max = load_temp;
			}
		}
		
		
		// calculate the fi (center & left & right)
		double deltaFi = load_max - load_min;
		double fi_center = (deltaFi * 1/2) + load_min;
		double fi_left = (deltaFi * 1/4) + load_min;
		double fi_right = (deltaFi * 3/4) + load_min;
		
		
		// create the leaf of tree
		ArrayList<Vm> myList1 = new ArrayList<Vm>();
		ArrayList<Vm> myList2 = new ArrayList<Vm>();
		ArrayList<Vm> myList3 = new ArrayList<Vm>();
		ArrayList<Vm> myList4 = new ArrayList<Vm>();
		double temp_fi = 0;
		
		for (int i = 0; i < getVmList().size(); i++) {
			temp_fi = normalization_cost(i);
			
			if (temp_fi < fi_center) {
				
				if (temp_fi < fi_left) {
					myList1.add(getVmList().get(i));
				} else {
					myList2.add(getVmList().get(i));
				}
				
			} else {

				if (temp_fi < fi_right) {
					myList3.add(getVmList().get(i));
				} else {
					myList4.add(getVmList().get(i));
				}				
				
			}			
		}
	
		
		if (myList1.size() == 0) {
			myList1.add(getVmList().get(loadMinId));
		}
		
		
//		//TODO print
//		System.out.print("\nmyList1 = ");
//		for (int i = 0; i < myList1.size(); i++) 
//			System.out.print(myList1.get(i).getId() + " ");
//		System.out.print("\nmyList2 = ");
//		for (int i = 0; i < myList2.size(); i++) 
//			System.out.print(myList2.get(i).getId() + " ");
//		System.out.print("\nmyList3 = ");
//		for (int i = 0; i < myList3.size(); i++) 
//			System.out.print(myList3.get(i).getId() + " ");
//		System.out.print("\nmyList4 = ");
//		for (int i = 0; i < myList4.size(); i++) 
//			System.out.print(myList4.get(i).getId() + " ");
//		System.out.println();
		
		
		// return final list
		return myList1;
	}

	
	
	public double[][] findtime_list() {
		// TODO Auto-generated method stub
		return ft_list;		
	}
	
	
	public double getSubmitTime() {
		return submit_time;
	}
	
	public double[][] getRunStartT() {
		return runStartT;
	}



	public double getFindTime_all() {
		// TODO Auto-generated method stub
		return findTime_all;
	}
	
	public double getFindTime_all_clock() {
		return findTime_all_clock;
	}
	
}
