/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation
 *               of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009, The University of Melbourne, Australia
 */


package uni_conf;


import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletSchedulerTimeShared;
import org.cloudbus.cloudsim.Datacenter;
//import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicySimple;
import org.cloudbus.cloudsim.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;


/**
 *  CloudSim
 */
public class CloudSim_uni_conf {

	public static int myAI = 0;			// 0=gwo | 1=decisionTree
	private static List<Vm> vmlist;
	private static List<Cloudlet> cloudletList;
	public static int[] vmLoad;
	public static int[] task_lenghts;
		
	public static double wholeTime_new_0 = 0;
	public static double wholeTime_new_1 = 0;

	
	public static double makespan = 0;
	public static double makespan_0 = 0;
	public static double makespan_1 = 0;
	
	public static double resourceUtilization = 0;
	public static double resourceUtilization_0 = 0;
	public static double resourceUtilization_1 = 0;

	
//	public static double first_moment = 0;
//	public static double makespan_new = 0;
//	public static double last_moment = 0;

//	public static long first_moment = 0;
//	public static long makespan_new = 0;
//	public static long last_moment = 0;
//	public static long wholeTime_new = 0;
//	public static long Time_new = 0;
//	
//	public static long sigmaPT_new = 0; 
//	
//	public static long utiliz_new = 0;
//	public static long res_utiliz_new = 0;
	
	

	public static double first_moment = 0;
//	public static double makespan_new = 0;
	public static double last_moment = 0;
	public static double wholeTime_new = 0;
	public static double Time_new = 0;
	public static double Time_new_currenttime = 0;
	
	public static double sigmaPT_new = 0; 

	public static double utiliz_new = 0;
	public static double res_utiliz_new = 0;
	
//	public static double utiliz_new_currentTime = 0;
//	public static double res_utiliz_new_currentTime = 0;
	
	
	
	/**
	 *  Main()
	 */
	public static void main(String[] args) {
		
		
		Log.printLine("\nStarting CloudSim -> Uni_Conf...\n");

		try {

			// init
			int vms = 20;
			int tasks = 100;
			
			vmLoad = new int[vms];
			
			task_lenghts = new int[tasks];
			
			for (int i = 0; i < tasks; i++) {
				task_lenghts[i] = randomLength();			
			}			
			
			for (int i = 0; i < vms; i++) {
				vmLoad[i] = 0;
			}

			
			/**
			 * *************************************************************************
			 */

			
			
			/*
			 *  without decision tree
			 */
			long startTime_0 = System.currentTimeMillis();
			myAI = 0;
			myCloudsimRun(vms, tasks, myAI);
			long endTime_0 = System.currentTimeMillis();

			// fill with result	
			
			wholeTime_new = last_moment - first_moment;
			System.out.println("wholeTime_new = " + wholeTime_new);
			
			wholeTime_new_0 = wholeTime_new;
			makespan_0 = Time_new_currenttime;
			resourceUtilization_0 = res_utiliz_new;
			
			

			System.out.println("\n\n\n\n");
			
			
			
//			System.out.println("makespan_new = " + makespan_new);
//			System.out.println("");
			
			
			/**
			 * *************************************************************************
			 */

			
			
			first_moment = 0;
//			makespan_new = 0;
			last_moment = 0;
			wholeTime_new = 0;
			Time_new = 0;
			Time_new_currenttime = 0;
			
			sigmaPT_new = 0; 
			
			utiliz_new = 0;
			res_utiliz_new = 0;			

			
			/**
			 * *************************************************************************
			 */

			
			/*
			 *  with decision tree
			 */
			long startTime_1 = System.currentTimeMillis();
			myAI = 1;
			myCloudsimRun(vms, tasks, myAI);
			long endTime_1 = System.currentTimeMillis();

			// fill with result
//			makespan_1 = makespan;
//			resourceUtilization_1 = resourceUtilization;
//			
////			makespan_1 = makespan;
////			resourceUtilization_1 = resourceUtilization;
//
//			wholeTime_new = last_moment - first_moment;
//			System.out.println("wholeTime_new = " + wholeTime_new);
//			System.out.println("\n\n\n\n");
//			

			wholeTime_new = last_moment - first_moment;
			System.out.println("wholeTime_new = " + wholeTime_new);
			

			wholeTime_new_1 = wholeTime_new;
			makespan_1 = Time_new_currenttime;
			resourceUtilization_1 = res_utiliz_new;
			
			

			System.out.println("\n\n\n\n");
			
			
			/**
			 * *************************************************************************
			 */

			
			
			/** print my result */
			
			// response time
			long difTime_0 = endTime_0 - startTime_0;						
			long difTime_1 = endTime_1 - startTime_1;		
//			System.out.println("\n\nResponse Time:");
//			System.out.println("ResponseTime_0 = " + difTime_0);
//			System.out.println("ResponseTime_1 = " + difTime_1);
			System.out.println("\n\nResponse Time:");
			System.out.println("ResponseTime_0 = " + wholeTime_new_0);
			System.out.println("ResponseTime_1 = " + wholeTime_new_1);
			
			
			// makespan
			System.out.println("\n\nMakespan: ");
			System.out.println("makespan_0 = " + makespan_0);
			System.out.println("makespan_1 = " + makespan_1);
			
			
			// resource utilization
			System.out.println("\n\nResource Utilization: ");
			System.out.println("ResourceUtilization_0 = " + resourceUtilization_0);
			System.out.println("ResourceUtilization_1 = " + resourceUtilization_1);
			
			
			//
			
			
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
			Log.printLine("The simulation has been terminated due to an unexpected error");
		}
	}
	
	
	// -------------------------------------------------------------------------------------------------------
	/** myCloudsimRun() */
	public static void myCloudsimRun(int vms_i, int tasks_i, int myAI_i) {

		first_moment = System.currentTimeMillis();
//		first_moment = CloudSim.clock();
		
		/**
		 *  First step: Initialize the CloudSim package.
		 *  It should be called before creating any entities.
		 */
		int num_user = 1;   							// number of grid users
		Calendar calendar = Calendar.getInstance();
		boolean trace_flag = false;  					// mean trace events

		// Initialize the CloudSim library
		CloudSim.init(num_user, calendar, trace_flag);

		
		/**
		 *  Second step: Create Datacenters
		 *  Datacenters are the resource providers in CloudSim. 
		 *  We need at list one of them to run a CloudSim simulation
		 */
		@SuppressWarnings("unused")
		Datacenter datacenter0 = createDatacenter("Datacenter_0");
		
		
		/**
		 *  Third step: Create Broker
		 */
		DatacenterBroker_uni_conf broker = createBroker();
		int brokerId = broker.getId();

		
		/**
		 *  Fourth step: Create VMs and Cloudlets 
		 *  and send them to broker
		 */
		vmlist = createVM(brokerId, vms_i);
		cloudletList = createCloudlet(brokerId, tasks_i);
		
		broker.submitVmList(vmlist, vms_i);
		broker.submitCloudletList(cloudletList, tasks_i);

		
		/**
		 *  Fifth step: Starts the simulation
		 */
		broker.intAI(myAI_i);
		CloudSim.startSimulation();
		CloudSim.stopSimulation();
		
		
		/**
		 *  Final step: Print results when simulation is over
		 */
		List<Cloudlet> newList = broker.getCloudletReceivedList();
		printCloudletList(newList, broker, vms_i);
		Log.printLine("CloudSim finished!\n\n\n");		
		
		
		last_moment = System.currentTimeMillis();
//		last_moment = CloudSim.clock();
		
	}
	// -------------------------------------------------------------------------------------------------------

	
	/** createVM() */
	private static List<Vm> createVM(int userId, int vms_i) {

		// creates a container to store VMs. This list is passed to the broker later
		LinkedList<Vm> list = new LinkedList<Vm>();

		// VM Parameters
		int vms = vms_i;
		// int vmLoad;			// randomly in global area
		long size = 10000; 		// image size (MB)
		long freeSize = size;	// useless
		int ram = 512; 			// vm memory (MB)
		int mips = 1000;
		long bw = 1000;
		int pesNumber = 1; 		// number of cpus
		String vmm = "Xen";		// VMM name

		int myParametr = 5;		// it is just for my test
		
		
		// create VMs
		Vm[] vm = new Vm[vms];

		for(int i = 0; i < vms; i++) {
			vm[i] = new Vm(i, userId, myParametr, vmLoad[i], mips, pesNumber, 
					ram, bw, size, freeSize, vmm, new CloudletSchedulerTimeShared());
			list.add(vm[i]);
		}
		
		return list;
	}
	
	
	
	/** createCloudlet() */
	private static List<Cloudlet> createCloudlet(int userId, int numberOfTasks) {
		
		// creates a container to store Cloudlets
		LinkedList<Cloudlet> list = new LinkedList<Cloudlet>();

		// cloudlet parameters
		int cloudlets = numberOfTasks;
		// int length = 0;			// randomly in global area
		int complexity = 1;		// 
		long fileSize = 300;
		long outputSize = 300;
		int pesNumber = 1;
		
		int myTaskParam = 4;		// it is just for my test
		
		UtilizationModel utilizationModel = new UtilizationModelFull();
		
		
		// create Cloudlets
		Cloudlet[] cloudlet = new Cloudlet[cloudlets];
		
		for(int i = 0; i < cloudlets; i++) {
			cloudlet[i] = new Cloudlet(i, task_lenghts[i], myTaskParam, task_lenghts[i], complexity, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
			cloudlet[i].setUserId(userId);
			list.add(cloudlet[i]);
		}

		return list;
	}
	
	
	
	// ----------------------------------------------------------
	/** random_range() */
	public static int random_range(int min, int max) {
		return (int) (Math.random() * (max - min) + min);
	}	
	// ----------------------------------------------------------
	
	

	// ----------------------------------------------------------
	/** random_cloudlet() */
	private static int randomLength() {

		int num = 3;
		num++;
		int rand = (int) (Math.random() * (num - 1) + 1);

		if (rand == 1) {
			return 500;
		} else if (rand == 2) {
			return 1000;
		} else if (rand == 3) {
			return 1500;
		} else {
			System.out.println("\n\n\n\n\n... Error ...\n\n\n\n\n");
			return 1000;
		}
	}
	// ----------------------------------------------------------
	
	
	
	/**
	 *  Create Datacenter()
	 */
	private static Datacenter createDatacenter(String name) {

		/*
		 *  1. Here are the steps needed to create a PowerDatacenter:
		 *  We need to create a list to store one or more Machines
		 */
		List<Host> hostList = new ArrayList<Host>();

		
		/*
		 *  2. A Machine contains one or more PEs or CPUs/Cores.
		 *  Therefore, should create a list to store these PEs before creating a Machine. 
		 */
		List<Pe> peList1 = new ArrayList<Pe>();

		
		/*
		 *  3. Create PEs and add these into the list.
		 *  for a quad-core machine, a list of 4 PEs is required:
		 */
		int mips = 100000;		// host speed (MIPS)
//		int mips = 1000;
		peList1.add(new Pe(0, new PeProvisionerSimple(mips)));	// need to store Pe id and MIPS Rating
		peList1.add(new Pe(1, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(2, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(3, new PeProvisionerSimple(mips)));

		/*
		//Another list, for a dual-core machine
		List<Pe> peList2 = new ArrayList<Pe>();

		peList2.add(new Pe(0, new PeProvisionerSimple(mips)));
		peList2.add(new Pe(1, new PeProvisionerSimple(mips)));
		*/
		
		
		/*
		 *  4. Create Hosts with its id and list of PEs and add them to the list of machines
		 */
		int hostId = 0;
		int ram = 32768;				//host memory (MB)
		long storage = 1000000;			//host storage
		int bw = 100000;
		
		/*
		int hostId=0;
		int ram = 2048;
		long storage = 1000000;
		int bw = 10000;
		*/

		hostList.add(
    			new Host(
    				hostId,
    				new RamProvisionerSimple(ram),
    				new BwProvisionerSimple(bw),
    				storage,
    				peList1,
    				new VmSchedulerTimeShared(peList1)
    			)
    		);


		/*
		 *  5. Create a DatacenterCharacteristics object that stores the properties of a data center: 
		 *  architecture, OS, list of Machines, allocation policy: 
		 *  time- or space-shared, time zone and its price (G$/Pe time unit).
		 */
		String arch = "x86";      		// system architecture
		String os = "Linux";          	// operating system
		String vmm = "Xen";
		double time_zone = 10.0;        // time zone this resource located
		double cost = 3.0;              // the cost of using processing in this resource
		double costPerMem = 0.05;		// the cost of using memory in this resource
		double costPerStorage = 0.1;	// the cost of using storage in this resource
		double costPerBw = 0.1;			// the cost of using bw in this resource
		LinkedList<Storage> storageList = new LinkedList<Storage>();	//we are not adding SAN devices by now

		DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
                arch, os, vmm, hostList, time_zone, cost, costPerMem, costPerStorage, costPerBw);


		/*
		 *  6. Finally, we need to create a PowerDatacenter object.
		 */
		Datacenter datacenter = null;
		
		try {
			datacenter = new Datacenter(name, characteristics, new VmAllocationPolicySimple(hostList), storageList, 0);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return datacenter;
	}
	
	// -------------------------------------------------------------------------------------------------------

	/**
	 *  We strongly encourage users to develop their own broker policies, 
	 *  to submit vms and cloudlets according to the specific rules of the simulated scenario
	 */
	private static DatacenterBroker_uni_conf createBroker() {

		DatacenterBroker_uni_conf broker = null;
		
		try {
			broker = new DatacenterBroker_uni_conf("Broker");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
		return broker;
	}

	// -------------------------------------------------------------------------------------------------------

	/**
	 * Prints the Cloudlet objects
	 * @param list  list of Cloudlets
	 * @param broker 
	 * @param m 
	 */
	private static void printCloudletList(List<Cloudlet> list, DatacenterBroker_uni_conf broker, int m) {

		
		//TODO - Makespan
		/**
		 * create start_list_final[size]
		 * create end_list_final[size]
		 * 
		 * store in start_list_final
		 * store in end_list_final
		 * 
		 * minimum of start_list_final => start_final
		 * maximum of end_list_final => end_final
		 * 
		 * end - start => makespan (public static)
		 * 
		 * initialize of makespan_0
		 * initialize of makespan_1
		 * 
		 * print makespan_0
		 * print makespan_1
		 * 
		 */
		
		
		
		//TODO - ResourceUtilization
		/**
		 * sum of pt => sigmaPT
		 * 
		 * submit time (just before and after if,else) => findTime
		 * 
		 * findTime - sigmaPT => PT_final
		 * 
		 * PT_final / makespan => utilization_final
		 * 
		 * -----
		 * 
		 * utilization_final / m => resourceUtilization
		 * 
		 * +++++
		 * 
		 * initialize of resourceUtilization_0
		 * initialize of resourceUtilization_1
		 * 
		 * print resourceUtilization_0
		 * print resourceUtilization_1
		 * 
		 */
		
		
		
		int size = list.size();
		Cloudlet cloudlet;
//		Vm vm = null;
		
//		System.out.println("1 = " + vm.getCloudletScheduler().getPreviousTime());
		
		
		String indent = "    ";
		System.out.println("\nHello world...\n");

		Log.printLine();
		Log.printLine("========== OUTPUT ==========");
		Log.printLine("Cloudlet ID" + indent 
				+ "STATUS" + indent 
				+ "DataCenter ID" + indent 
				+ "VM ID" + indent + indent 
				+ "Time" + indent + indent
				+ "Start Time" + indent + indent
				+ "Finish Time");
		
		DecimalFormat dft = new DecimalFormat("###.##");

		double[] start_list_final = new double[size];
		double[] end_list_final = new double[size];
		double[] end_list_currentTime = new double[size];
		
		double[] pt_list = new double[size];
		
		
//		long[] start_list_final = new long[size];
//		long[] end_list_final = new long[size];
//		
//		long[] pt_list = new long[size];
		
//		double makespan_new = 0;
		
		
		for (int i = 0; i < size; i++) {

			cloudlet = list.get(i);

			int myCloudletID = cloudlet.getCloudletId();
//			int myVmID = cloudlet.getVmId(); 
			
			//Log.print(indent + cloudlet.getCloudletId() + indent + indent);

			if (cloudlet.getCloudletStatus() == Cloudlet.SUCCESS) {
				
				Log.print("SUCCESS");

				Log.printLine( indent + indent + cloudlet.getResourceId() 
					+ indent + indent + indent + cloudlet.getVmId() 
					+ indent + indent + indent + dft.format(cloudlet.getActualCPUTime())
					+ indent + indent + dft.format(cloudlet.getExecStartTime())
					+ indent + indent + indent + dft.format(cloudlet.getFinishTime()));
				

//				start_list_final[myCloudletID] = (long) cloudlet.getExecStartTime();
//				end_list_final[myCloudletID] = (long) cloudlet.getFinishTime();
//				
//				pt_list[myCloudletID] = (long) cloudlet.getActualCPUTime();

				
				
				//TODO 
				start_list_final[myCloudletID] = cloudlet.getExecStartTime();
				end_list_final[myCloudletID] = cloudlet.getFinishTime();
				end_list_currentTime[myCloudletID] = cloudlet.getFinishTime_currentTime();
				pt_list[myCloudletID] = cloudlet.getActualCPUTime();

				
				
				
				
//				System.out.println("\n");
//				
//				System.out.println("start_list_final = " + start_list_final[myCloudletID]);
//				System.out.println("end_list_final = " + end_list_final[myCloudletID]);
//				System.out.println("pt_list = " + pt_list[myCloudletID]);
//				
//				System.out.println("last_time = " + (end_list_final[myCloudletID] - start_list_final[myCloudletID]));
//				
//				
//				
//				System.out.println("\n");
			}
			
		}
		System.out.println("\n\n");
		
	
//		
//		
//
//		double min_start = start_list_final[0];
//		for (int x = 0; x < size; x++) {
//			if (start_list_final[x] < min_start) {
//				min_start = start_list_final[x];
//			}
//		}
//		double max_end = 0;
//		for (int y = 0; y < size; y++) {
//			if (end_list_final[y] > max_end) {
//				max_end = end_list_final[y];
//			}
//		}
//		
//		
//		makespan = max_end - min_start; 
//		
//		
//		
//		
//		double sigmaPT = 0;
//		for (int s = 0; s < size; s++) {
//			sigmaPT += pt_list[s];
//		}
//		
//		
//		double findTime = broker.getFindTime_all();
//		double findTime_clock = broker.getFindTime_all_clock();
//		
//		
//		double pt_final = sigmaPT - findTime;
//		
//		
//		double utilization_final = pt_final / makespan;
//		
//		
//		resourceUtilization = utilization_final / m;
//		
//		
		
		
		//
		
		
		//TODO
		// max_end_list_task => the last time when all task are finished (the moment of last task, is finished)
		double last_moment_last_task = end_list_final[0];
		for (int i = 0; i < end_list_final.length; i++) {
			if (last_moment_last_task < end_list_final[i]) {
				last_moment_last_task = end_list_final[i];
			}
		}
		
		double last_moment_currentTime = end_list_currentTime[0];
		for (int i = 0; i < end_list_currentTime.length; i++) {
			if (last_moment_currentTime < end_list_currentTime[i]) {
				last_moment_currentTime = end_list_currentTime[i];
			}
		}
		
		
		
		// makespan_new = max_end_list_task - first_moment;
//		makespan_new = last_moment_last_task - first_moment;
		
//		System.out.println("makespan_new = " + makespan_new);
		
		
		
		
//		last_moment = System.currentTimeMillis();

		
		for (int i = 0; i < pt_list.length; i++) {
			sigmaPT_new += pt_list[i];
		}
		
		
		
		

		//TODO => new
		System.out.println("\n\n\n\n");

		// responseTimeNew
		wholeTime_new = last_moment - first_moment;
		System.out.println("wholeTime_new = " + wholeTime_new);
		System.out.println("\n\n");
				
		// makespanNew
//		Time_new = last_moment_last_task - first_moment;
//		System.out.println("makespan_new = " + Time_new);
		
		Time_new_currenttime = last_moment_currentTime - first_moment;
		System.out.println("makespan_new_currentTime = " + Time_new_currenttime);
		
		System.out.println("\n\n");
		
		// utilizationNew
//		System.out.println("findTime = " + findTime);
//		System.out.println("findTime_clock = " + findTime_clock);
//				
//		System.out.println("sigmaPT = " + sigmaPT);
//		System.out.println("pt_final = " + pt_final);
//		utiliz_new = sigmaPT / Time_new;
//		utiliz_new = pt_final / Time_new;
		System.out.println();
		System.out.println("sigmaPT_new = " + sigmaPT_new);
		
//		utiliz_new = sigmaPT_new / Time_new;
		utiliz_new = sigmaPT_new / Time_new_currenttime;
		
		System.out.println("utilization_new = " + utiliz_new);
		
		
		
		System.out.println("\n\n");
		
		// resourceUtilizationNew
		res_utiliz_new = utiliz_new / m;
		System.out.println("res_utiliz_new = " + res_utiliz_new);
		
		
		
		System.out.println("\n\n");
		
		
		
		
		
		
		
		System.out.println("\n\n");
	}
	
	
}
