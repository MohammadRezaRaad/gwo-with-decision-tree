package uni_conf;

import java.util.Arrays;

public class Test_ArrayFill {

	public static int[] arrayFill;
	public static int[][] arr2d;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int vms = 20;
		int tasks = 100;
		
		arrayFill = new int[vms];
		arr2d = new int[vms][5];
		
		
		Arrays.fill(arrayFill, 3);
		
		
		System.out.println(Arrays.toString(arrayFill));
		
		
		
		
//		Arrays.fill(ar, 10);
//        System.out.println("Array completely filled" + " with 10\n" + Arrays.toString(ar));
		
		
		
	}

}
